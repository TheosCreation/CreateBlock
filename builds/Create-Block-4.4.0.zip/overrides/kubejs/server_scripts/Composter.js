
ServerEvents.compostableRecipes(event => {
    event.add("kubejs:mycelium_spores", 0.5)
    event.add("kubejs:crimson_nylium_spores", 0.5)
    event.add("kubejs:warped_nylium_spores", 0.5)
})