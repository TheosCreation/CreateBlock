/*
ServerEvents.recipes(event => {
	event.remove({ output: 'projecte:swiftwolf_rending_gale' })
	event.remove({ output: 'projecte:philosophers_stone' })
	// philosophers stone
	event.shaped('projecte:philosophers_stone', [
		'BBB',
		'BSB',
		'BBB'
	], {
		B: 'createdeco:netherite_bars',
		S: 'minecraft:nether_star'
	})
	// swiftwolf ring
	event.shaped('projecte:swiftwolf_rending_gale', [
		'DFD',
		'FRF',
		'DFD'
	], {
		R: 'angelring:angel_ring',
		F: '#forge:feathers',
		D: 'projecte:dark_matter'
	})
});
*/