interface String {
     readonly namespace: string,
     readonly path: string
}
